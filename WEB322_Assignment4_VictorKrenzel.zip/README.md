## Seneca College WEB322 Assignment
###### Using MongoDB for user authentication
